const list = document.querySelector("#list");
const bars = document.querySelector("#bars");

async function load() {
  const rows = await (await fetch("/api/expenses")).json();
  list.replaceChildren(...rows.map((r) => {
    const li = document.createElement("li");
    li.textContent = `${r.title}: ${r.amount.toFixed(2)}`;
    return li;
  }));
  const max = Math.max(1, ...rows.map((r) => r.amount));
  bars.replaceChildren(...rows.map((r) => {
    const bar = document.createElement("div");
    bar.className = "bar";
    bar.style.width = `${(r.amount / max) * 100}%`;
    bar.textContent = r.title;
    return bar;
  }));
}

document.querySelector("#add").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = new FormData(e.target);
  await fetch("/api/expenses", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title: form.get("title"), amount: form.get("amount") }),
  });
  e.target.reset();
  load();
});

load();
