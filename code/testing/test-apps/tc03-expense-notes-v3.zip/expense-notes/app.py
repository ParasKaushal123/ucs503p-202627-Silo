import json
import os
import sqlite3
import subprocess

import requests
from flask import Flask, jsonify, render_template, request

app = Flask(__name__)
DB = "expenses.db"
RATES_URL = os.environ.get("RATES_URL", "https://api.exchangerates.example.com/latest")
RATES_API_KEY = os.environ.get("RATES_API_KEY", "")
# Only these fixed queries can run; the client picks one by name.
LIST_QUERIES = {
    "id": "SELECT id, title, amount FROM expenses ORDER BY id DESC",
    "amount": "SELECT id, title, amount FROM expenses ORDER BY amount DESC",
}


def db():
    conn = sqlite3.connect(DB)
    conn.execute("CREATE TABLE IF NOT EXISTS expenses (id INTEGER PRIMARY KEY, title TEXT, amount REAL)")
    return conn


@app.get("/")
def home():
    return render_template("index.html")


@app.get("/api/expenses")
def list_expenses():
    query = LIST_QUERIES.get(request.args.get("order", "id"), LIST_QUERIES["id"])
    rows = db().execute(query).fetchall()
    return jsonify([{"id": r[0], "title": r[1], "amount": r[2]} for r in rows])


@app.post("/api/expenses")
def add_expense():
    data = request.get_json()
    conn = db()
    conn.execute("INSERT INTO expenses (title, amount) VALUES (?, ?)", (data["title"], float(data["amount"])))
    conn.commit()
    return {"ok": True}, 201


@app.get("/api/convert")
def convert():
    currency = request.args.get("to", "EUR")
    rates = requests.get(RATES_URL, params={"key": RATES_API_KEY}, timeout=10).json()
    return {"rate": rates.get(currency)}


@app.get("/export")
def export_csv():
    result = subprocess.run(
        ["sqlite3", "-csv", DB, "select * from expenses"], capture_output=True, text=True
    )
    with open("export.csv", "w") as f:
        f.write(result.stdout)
    return {"file": "export.csv"}


@app.post("/backup/restore")
def restore():
    with open("backup.json", "w") as f:
        f.write(request.get_data(as_text=True))
    with open("backup.json") as f:
        rows = json.load(f)
    return {"restored": len(rows), "by": os.environ.get("USER", "unknown")}


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
