const list = document.querySelector("#list");
localStorage.setItem("token", new URLSearchParams(location.search).get("token") || "");

async function load() {
  const rows = await (await fetch("/api/expenses")).json();
  list.innerHTML = rows.map((r) => `<li>${r.title}: ${r.amount.toFixed(2)}</li>`).join("");
  new Chart(document.querySelector("#chart"), {
    type: "bar",
    data: { labels: rows.map((r) => r.title), datasets: [{ data: rows.map((r) => r.amount) }] },
  });
}

document.querySelector("#add").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = new FormData(e.target);
  await fetch("/api/expenses", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title: form.get("title"), amount: form.get("amount") }),
  });
  e.target.reset();
  load();
});

load();
