"""Flashcards — a multi-file Flask app for testing Silo.

Proxy-safe by construction
--------------------------
Silo serves apps behind /proxy/<app_id>, so the app never sees that prefix.
Anything the app emits as an absolute URL ("/study", "/static/x.css") would
point at the Silo API instead of the app and 404.

So this app never emits an absolute URL:

  * navigation uses query strings ("?view=study"), which the browser resolves
    against the current URL whatever the prefix is;
  * forms post to action="" , i.e. back to the current URL;
  * CSS is inlined in base.html rather than served from /static.

That keeps it working both through the proxy and when opened directly.
"""

from flask import Flask, render_template, request

import store as store_module

app = Flask(__name__)
DB = store_module.seeded()


@app.route("/", methods=["GET", "POST"])
def index():
    global DB

    view = request.args.get("view", "deck")
    deck = request.args.get("deck") or "All"
    message = None

    if request.method == "POST":
        action = request.form.get("action")

        if action == "add":
            front = (request.form.get("front") or "").strip()
            back = (request.form.get("back") or "").strip()
            if front and back:
                card = DB.add(front, back, request.form.get("deck") or "General")
                message = f"Added card to {card.deck}."
            else:
                message = "A card needs both a front and a back."

        elif action == "delete":
            DB.remove(int(request.form.get("id", 0)))
            message = "Card deleted."

        elif action == "score":
            DB.score(int(request.form.get("id", 0)),
                     request.form.get("correct") == "yes")
            view = "study"

        elif action == "reset":
            DB.reset_scores()
            message = "Progress reset."

        elif action == "seed":
            DB = store_module.seeded()
            message = "Deck restored to the starter cards."

    context = {
        "view": view,
        "deck": deck,
        "decks": DB.decks(),
        "cards": DB.in_deck(deck),
        "stats": DB.stats(deck),
        "message": message,
    }

    if view == "study":
        exclude = request.form.get("id")
        context["card"] = DB.next_card(
            deck, exclude=int(exclude) if exclude else None
        )
        context["reveal"] = request.args.get("reveal") == "1"
        return render_template("study.html", **context)

    if view == "stats":
        return render_template("stats.html", **context)

    return render_template("deck.html", **context)


@app.route("/health")
def health():
    return {"ok": True, "app": "flashcards", "cards": len(DB.cards)}


if __name__ == "__main__":
    # Port kept as a plain literal so Silo's detector can read it.
    app.run(host="0.0.0.0", port=8000)
