"""Data layer for the flashcard app.

Kept separate from app.py so the project is genuinely multi-file: Silo has to
copy the whole directory into the image and get the working directory right,
not just run one script.

State lives in memory. It resets when the container restarts, which is fine --
the point is to prove that server state survives across requests.
"""

from dataclasses import dataclass, field, asdict
from itertools import count

_ids = count(1)


@dataclass
class Card:
    id: int
    front: str
    back: str
    deck: str = "General"
    right: int = 0
    wrong: int = 0

    @property
    def seen(self) -> int:
        return self.right + self.wrong

    @property
    def accuracy(self) -> int:
        return round(self.right / self.seen * 100) if self.seen else 0

    @property
    def grade(self) -> str:
        """Bucket a card so the UI can colour it."""
        if self.seen == 0:
            return "new"
        if self.accuracy >= 80:
            return "strong"
        if self.accuracy >= 50:
            return "shaky"
        return "weak"


@dataclass
class Store:
    cards: list[Card] = field(default_factory=list)

    # -- mutations ---------------------------------------------------------

    def add(self, front: str, back: str, deck: str = "General") -> Card:
        card = Card(id=next(_ids), front=front.strip(), back=back.strip(),
                    deck=(deck or "General").strip())
        self.cards.append(card)
        return card

    def remove(self, card_id: int) -> None:
        self.cards = [c for c in self.cards if c.id != card_id]

    def score(self, card_id: int, correct: bool) -> None:
        for c in self.cards:
            if c.id == card_id:
                if correct:
                    c.right += 1
                else:
                    c.wrong += 1

    def reset_scores(self) -> None:
        for c in self.cards:
            c.right = c.wrong = 0

    # -- queries -----------------------------------------------------------

    def decks(self) -> list[str]:
        return sorted({c.deck for c in self.cards})

    def in_deck(self, deck: str | None) -> list[Card]:
        if not deck or deck == "All":
            return list(self.cards)
        return [c for c in self.cards if c.deck == deck]

    def next_card(self, deck: str | None, exclude: int | None = None) -> Card | None:
        """Pick what to study next: least-seen first, then weakest.

        A tiny bit of real logic so the app does something more interesting
        than echo a form back.
        """
        pool = [c for c in self.in_deck(deck) if c.id != exclude]
        if not pool:
            pool = self.in_deck(deck)
        if not pool:
            return None
        return sorted(pool, key=lambda c: (c.seen, c.accuracy))[0]

    def stats(self, deck: str | None = None) -> dict:
        cards = self.in_deck(deck)
        seen = sum(c.seen for c in cards)
        right = sum(c.right for c in cards)
        return {
            "total": len(cards),
            "reviews": seen,
            "accuracy": round(right / seen * 100) if seen else 0,
            "new": sum(1 for c in cards if c.grade == "new"),
            "strong": sum(1 for c in cards if c.grade == "strong"),
            "shaky": sum(1 for c in cards if c.grade == "shaky"),
            "weak": sum(1 for c in cards if c.grade == "weak"),
        }

    def as_dicts(self) -> list[dict]:
        return [asdict(c) for c in self.cards]


SEED = [
    ("What does HTTP 502 mean?", "Bad Gateway — an upstream server gave an invalid response.", "Web"),
    ("What does a Dockerfile's EXPOSE do?", "Documents the port. It does not publish it — that needs -p.", "Docker"),
    ("Difference between WSGI and ASGI?", "WSGI is synchronous (Flask). ASGI is async (FastAPI).", "Python"),
    ("Why bind to 0.0.0.0 in a container?", "127.0.0.1 is only reachable inside the container itself.", "Docker"),
    ("What is a Python walrus operator?", ":= assigns inside an expression. Added in 3.8.", "Python"),
    ("What does CASCADE do on a foreign key?", "Deleting the parent row deletes the dependent rows too.", "Databases"),
]


def seeded() -> Store:
    store = Store()
    for front, back, deck in SEED:
        store.add(front, back, deck)
    return store
