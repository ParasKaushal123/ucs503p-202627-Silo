# Flashcards

Multi-file Flask app used to test Silo.

    app.py              routes and request handling
    store.py            card storage, scoring, "what to study next" logic
    templates/          base.html, deck.html, study.html, stats.html
    requirements.txt

Features: add/delete cards, filter by deck, study mode that reveals answers and
records right/wrong, and a stats page with accuracy bars per card.

Entry point is app.py, which has a __main__ guard and binds 0.0.0.0:8000, so
Silo should run it as `python app.py`.
