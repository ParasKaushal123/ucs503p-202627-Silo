"""Expense Splitter — a small Flask app for testing Silo.

Everything is rendered from one route so it works cleanly behind Silo's
reverse proxy (/proxy/<app_id>). No extra HTTP requests, no static files,
no absolute URLs.
"""

from flask import Flask

app = Flask(__name__)

PAGE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Expense Splitter</title>
<style>
  :root {
    --ink: #111;
    --paper: #f7f7f5;
    --line: #111;
    --green: #55db9c;
    --yellow: #ffd731;
    --lilac: #e9ccff;
    --blue: #4da2ff;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    font-family: "Archivo", "Segoe UI", system-ui, sans-serif;
    background: var(--paper);
    color: var(--ink);
    padding: 24px 16px 48px;
  }
  .wrap { max-width: 720px; margin: 0 auto; }
  h1 {
    font-size: 30px; letter-spacing: -0.5px; margin: 0 0 4px;
  }
  .sub { color: #666; font-size: 14px; margin: 0 0 24px; }
  .card {
    border: 1px solid var(--line);
    border-radius: 20px;
    background: #fff;
    padding: 18px;
    margin-bottom: 16px;
  }
  label { display: block; font-size: 11px; font-weight: 700;
          text-transform: uppercase; letter-spacing: .06em;
          margin-bottom: 6px; color: #555; }
  input, select {
    width: 100%; padding: 10px 14px; font-size: 14px;
    border: 1px solid var(--line); border-radius: 999px;
    outline: none; font-family: inherit; background: #fff;
  }
  input:focus, select:focus { border-color: var(--blue); }
  .row { display: flex; gap: 10px; flex-wrap: wrap; }
  .row > div { flex: 1 1 140px; }
  button {
    border: 1px solid var(--line); border-radius: 999px;
    padding: 10px 18px; font-size: 13px; font-weight: 700;
    background: var(--ink); color: #fff; cursor: pointer;
    font-family: inherit;
  }
  button.ghost { background: #fff; color: var(--ink); }
  button:hover { opacity: .88; }
  table { width: 100%; border-collapse: collapse; font-size: 14px; }
  th { text-align: left; font-size: 11px; text-transform: uppercase;
       letter-spacing: .06em; color: #666; padding: 8px 6px;
       border-bottom: 1px solid var(--line); }
  td { padding: 10px 6px; border-bottom: 1px solid #e6e6e6; }
  tr:last-child td { border-bottom: 0; }
  .chip {
    display: inline-block; padding: 3px 10px; border-radius: 999px;
    border: 1px solid var(--line); font-size: 11px; font-weight: 700;
  }
  .totals { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px,1fr)); gap: 10px; }
  .tile { border: 1px solid var(--line); border-radius: 16px; padding: 14px; }
  .tile .k { font-size: 11px; text-transform: uppercase; letter-spacing:.06em; color:#555; }
  .tile .v { font-size: 24px; font-weight: 700; margin-top: 4px; }
  .settle { font-size: 14px; padding: 10px 0; border-bottom: 1px solid #eee; }
  .settle:last-child { border-bottom: 0; }
  .x { border: 0; background: none; color: #b00; cursor: pointer; font-size: 16px; padding: 0 4px; }
  .empty { text-align: center; color: #999; padding: 24px 0; font-size: 14px; }
  .badge { background: var(--green); }
</style>
</head>
<body>
<div class="wrap">
  <h1>Expense Splitter</h1>
  <p class="sub">Add what everyone paid. It works out who owes who. Running on Silo.</p>

  <div class="card">
    <div class="row">
      <div>
        <label>Who paid</label>
        <input id="who" placeholder="Paras" value="Paras">
      </div>
      <div>
        <label>For what</label>
        <input id="what" placeholder="Dinner">
      </div>
      <div>
        <label>Amount</label>
        <input id="amt" type="number" min="0" step="1" placeholder="1200">
      </div>
    </div>
    <div style="margin-top:12px; display:flex; gap:8px;">
      <button onclick="addExpense()">Add expense</button>
      <button class="ghost" onclick="loadSample()">Load sample</button>
      <button class="ghost" onclick="reset()">Clear</button>
    </div>
  </div>

  <div class="card">
    <table>
      <thead>
        <tr><th>Who</th><th>What</th><th style="text-align:right">Amount</th><th></th></tr>
      </thead>
      <tbody id="rows"></tbody>
    </table>
    <div id="empty" class="empty">No expenses yet. Add one above.</div>
  </div>

  <div class="card">
    <div class="totals" id="totals"></div>
  </div>

  <div class="card">
    <label style="margin-bottom:10px">Settle up</label>
    <div id="settle"></div>
  </div>
</div>

<script>
let expenses = [];

function addExpense() {
  const who = document.getElementById('who').value.trim();
  const what = document.getElementById('what').value.trim() || 'Expense';
  const amt = parseFloat(document.getElementById('amt').value);
  if (!who || !amt || amt <= 0) { alert('Enter a name and a positive amount.'); return; }
  expenses.push({ who, what, amt });
  document.getElementById('what').value = '';
  document.getElementById('amt').value = '';
  render();
}

function removeExpense(i) { expenses.splice(i, 1); render(); }

function loadSample() {
  expenses = [
    { who: 'Paras', what: 'Dinner',   amt: 1800 },
    { who: 'Aditi', what: 'Cab',      amt: 640  },
    { who: 'Rohan', what: 'Tickets',  amt: 2400 },
    { who: 'Paras', what: 'Snacks',   amt: 320  }
  ];
  render();
}

function reset() { expenses = []; render(); }

function render() {
  const rows = document.getElementById('rows');
  const empty = document.getElementById('empty');
  rows.innerHTML = '';
  empty.style.display = expenses.length ? 'none' : 'block';

  expenses.forEach((e, i) => {
    const tr = document.createElement('tr');
    tr.innerHTML =
      '<td><span class="chip">' + e.who + '</span></td>' +
      '<td>' + e.what + '</td>' +
      '<td style="text-align:right">&#8377;' + e.amt.toFixed(2) + '</td>' +
      '<td style="text-align:right"><button class="x" onclick="removeExpense(' + i + ')">&times;</button></td>';
    rows.appendChild(tr);
  });

  const people = [...new Set(expenses.map(e => e.who))];
  const total = expenses.reduce((s, e) => s + e.amt, 0);
  const share = people.length ? total / people.length : 0;

  const totals = document.getElementById('totals');
  totals.innerHTML =
    tile('Total spent', '\\u20B9' + total.toFixed(2)) +
    tile('People', String(people.length)) +
    tile('Each owes', '\\u20B9' + share.toFixed(2));

  const paid = {};
  people.forEach(p => paid[p] = 0);
  expenses.forEach(e => paid[e.who] += e.amt);

  const balances = people.map(p => ({ name: p, bal: paid[p] - share }));
  const owe = balances.filter(b => b.bal < -0.01).map(b => ({...b}));
  const get = balances.filter(b => b.bal >  0.01).map(b => ({...b}));

  const out = [];
  let i = 0, j = 0;
  while (i < owe.length && j < get.length) {
    const amount = Math.min(-owe[i].bal, get[j].bal);
    out.push(owe[i].name + ' pays ' + get[j].name + ' \\u20B9' + amount.toFixed(2));
    owe[i].bal += amount;
    get[j].bal -= amount;
    if (Math.abs(owe[i].bal) < 0.01) i++;
    if (Math.abs(get[j].bal) < 0.01) j++;
  }

  const settle = document.getElementById('settle');
  settle.innerHTML = out.length
    ? out.map(s => '<div class="settle">' + s + '</div>').join('')
    : '<div class="empty">Nothing to settle.</div>';
}

function tile(k, v) {
  return '<div class="tile"><div class="k">' + k + '</div><div class="v">' + v + '</div></div>';
}

loadSample();
</script>
</body>
</html>
"""


@app.route("/")
def index():
    return PAGE


@app.route("/health")
def health():
    return {"ok": True, "app": "expense-splitter"}


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
