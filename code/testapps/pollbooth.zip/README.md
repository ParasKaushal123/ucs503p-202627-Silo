# Poll Booth

Multi-file FastAPI app used to test Silo.

    main.py             ASGI app and form handling
    polls.py            poll model, vote counting, seeding
    templates/          index.html
    requirements.txt

Features: create polls with up to four options, vote, live percentage bars,
open/close a poll, delete polls.

main.py has NO `if __name__ == "__main__"` block. `python main.py` exits
immediately without serving anything, so Silo must detect the ASGI app and
start it with `uvicorn main:app --host 0.0.0.0 --port 8000`.
