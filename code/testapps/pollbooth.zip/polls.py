"""Poll data and vote counting.

Separate module from main.py so the project is genuinely multi-file and Silo
has to copy the package, set PYTHONPATH and get the working directory right.
"""

from dataclasses import dataclass, field
from datetime import datetime
from itertools import count

_ids = count(1)


@dataclass
class Option:
    label: str
    votes: int = 0


@dataclass
class Poll:
    id: int
    question: str
    options: list[Option]
    created: str = field(default_factory=lambda: datetime.now().strftime("%H:%M:%S"))
    closed: bool = False

    @property
    def total(self) -> int:
        return sum(o.votes for o in self.options)

    def share(self, option: Option) -> float:
        return (option.votes / self.total * 100) if self.total else 0.0

    @property
    def leader(self) -> Option | None:
        if not self.total:
            return None
        return max(self.options, key=lambda o: o.votes)

    @property
    def is_tie(self) -> bool:
        if not self.total:
            return False
        top = max(o.votes for o in self.options)
        return sum(1 for o in self.options if o.votes == top) > 1


class Booth:
    def __init__(self) -> None:
        self.polls: list[Poll] = []

    # -- mutations ---------------------------------------------------------

    def create(self, question: str, labels: list[str]) -> Poll | None:
        labels = [l.strip() for l in labels if l and l.strip()]
        question = question.strip()
        if not question or len(labels) < 2:
            return None
        poll = Poll(id=next(_ids), question=question,
                    options=[Option(label=l) for l in labels[:6]])
        self.polls.insert(0, poll)
        return poll

    def vote(self, poll_id: int, index: int) -> bool:
        poll = self.get(poll_id)
        if not poll or poll.closed:
            return False
        if 0 <= index < len(poll.options):
            poll.options[index].votes += 1
            return True
        return False

    def toggle(self, poll_id: int) -> None:
        poll = self.get(poll_id)
        if poll:
            poll.closed = not poll.closed

    def delete(self, poll_id: int) -> None:
        self.polls = [p for p in self.polls if p.id != poll_id]

    # -- queries -----------------------------------------------------------

    def get(self, poll_id: int) -> Poll | None:
        return next((p for p in self.polls if p.id == poll_id), None)

    @property
    def total_votes(self) -> int:
        return sum(p.total for p in self.polls)


# Neon bar colours, ordered so adjacent options never sit close in hue.
PALETTE = ["#2DE2E6", "#8AFF80", "#FFD23F", "#FF5E7D", "#A97BFF", "#FF9F45"]


def seeded() -> Booth:
    booth = Booth()
    booth.create("Which deploy target should we support next?",
                 ["Node.js", "Go", "Static sites", "Rust"])
    booth.create("How should build logs be shown?",
                 ["Live streaming", "On demand", "Only on failure"])
    p = booth.polls[-1]
    p.options[0].votes = 7
    p.options[1].votes = 3
    p.options[2].votes = 1
    q = booth.polls[0]
    q.options[0].votes = 4
    q.options[1].votes = 6
    q.options[2].votes = 2
    return booth
