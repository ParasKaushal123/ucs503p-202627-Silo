"""Poll Booth — a multi-file FastAPI app for testing Silo.

Note what is deliberately NOT here: there is no

    if __name__ == "__main__":
        uvicorn.run(...)

block. This module only defines an ASGI application object. Running it with
`python main.py` does nothing at all -- the process exits immediately and the
container dies while still reporting a successful start.

That makes this app a test of whether Silo notices it needs to be launched
with `uvicorn main:app` instead. Most real FastAPI projects look like this.

Like the flashcards app, every URL it emits is relative (query strings for
navigation, action="" for forms) so it works behind /proxy/<app_id>.
"""

from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

import polls as polls_module

app = FastAPI(title="Poll Booth")
templates = Jinja2Templates(directory="templates")

BOOTH = polls_module.seeded()


def _context(message: str | None = None) -> dict:
    return {
        "polls": BOOTH.polls,
        "message": message,
        "total_votes": BOOTH.total_votes,
        "palette": polls_module.PALETTE,
    }


@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    # Starlette >= 0.38 takes the request first; the old (name, context)
    # form is removed, so this is the modern signature.
    return templates.TemplateResponse(request, "index.html", _context())


@app.post("/", response_class=HTMLResponse)
def act(
    request: Request,
    action: str = Form(...),
    poll_id: int = Form(0),
    choice: int = Form(-1),
    question: str = Form(""),
    option1: str = Form(""),
    option2: str = Form(""),
    option3: str = Form(""),
    option4: str = Form(""),
):
    message = None

    if action == "create":
        poll = BOOTH.create(question, [option1, option2, option3, option4])
        message = f'Created "{poll.question}"' if poll else \
            "A poll needs a question and at least two options."

    elif action == "vote":
        message = "Vote counted." if BOOTH.vote(poll_id, choice) \
            else "That poll is closed."

    elif action == "toggle":
        BOOTH.toggle(poll_id)
        poll = BOOTH.get(poll_id)
        message = ("Poll closed." if poll and poll.closed else "Poll reopened.")

    elif action == "delete":
        BOOTH.delete(poll_id)
        message = "Poll deleted."

    elif action == "reset":
        BOOTH.polls = polls_module.seeded().polls
        message = "Reset to the starter polls."

    return templates.TemplateResponse(request, "index.html", _context(message))


@app.get("/health")
def health():
    return {"ok": True, "app": "pollbooth",
            "polls": len(BOOTH.polls), "votes": BOOTH.total_votes}
