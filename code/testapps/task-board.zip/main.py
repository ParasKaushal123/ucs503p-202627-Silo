"""Task Board — a small Flask app for testing Silo.

This one keeps state on the SERVER (in memory) and uses plain HTML form
POSTs back to the same URL. That makes it a good test of Silo's reverse
proxy handling POST requests, not just GETs.

Deliberately avoids redirects: a redirect would send a `Location: /`
header that points outside the /proxy/<app_id> prefix. Instead every
POST renders the page directly.
"""

from datetime import datetime

from flask import Flask, request

app = Flask(__name__)

# In-memory store. Resets when the container restarts — that is fine,
# the point is to prove server state survives across requests.
TASKS = [
    {"id": 1, "text": "Wire up the reverse proxy", "done": True, "lane": "Done"},
    {"id": 2, "text": "Auto-detect the container port", "done": True, "lane": "Done"},
    {"id": 3, "text": "Show a live preview on the home screen", "done": False, "lane": "Doing"},
    {"id": 4, "text": "Version rollback", "done": False, "lane": "Todo"},
    {"id": 5, "text": "Invite teammates to an app room", "done": False, "lane": "Todo"},
]
NEXT_ID = 6

LANES = ["Todo", "Doing", "Done"]
LANE_COLOR = {"Todo": "#dceeff", "Doing": "#ffd731", "Done": "#55db9c"}


def render() -> str:
    counts = {lane: sum(1 for t in TASKS if t["lane"] == lane) for lane in LANES}
    done = sum(1 for t in TASKS if t["done"])
    pct = round(done / len(TASKS) * 100) if TASKS else 0

    columns = ""
    for lane in LANES:
        cards = ""
        for t in TASKS:
            if t["lane"] != lane:
                continue
            strike = "text-decoration:line-through;opacity:.55;" if t["done"] else ""
            cards += f"""
            <div class="task" style="{strike}">
              <span>{t['text']}</span>
              <form method="post" class="inline">
                <input type="hidden" name="action" value="advance">
                <input type="hidden" name="id" value="{t['id']}">
                <button class="mini" title="Move forward">&rarr;</button>
              </form>
              <form method="post" class="inline">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="{t['id']}">
                <button class="mini danger" title="Delete">&times;</button>
              </form>
            </div>"""
        if not cards:
            cards = '<div class="empty">Nothing here</div>'

        columns += f"""
        <section class="col">
          <header style="background:{LANE_COLOR[lane]}">
            <span>{lane}</span><span class="count">{counts[lane]}</span>
          </header>
          <div class="body">{cards}</div>
        </section>"""

    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Task Board</title>
<style>
  * {{ box-sizing: border-box; }}
  body {{
    margin: 0; padding: 24px 16px 48px;
    font-family: "Archivo", "Segoe UI", system-ui, sans-serif;
    background: #f7f7f5; color: #111;
  }}
  .wrap {{ max-width: 900px; margin: 0 auto; }}
  h1 {{ font-size: 30px; margin: 0 0 4px; letter-spacing: -0.5px; }}
  .sub {{ color: #666; font-size: 14px; margin: 0 0 20px; }}
  .bar {{
    border: 1px solid #111; border-radius: 999px; height: 12px;
    background: #fff; overflow: hidden; margin-bottom: 6px;
  }}
  .bar > i {{ display: block; height: 100%; background: #55db9c; width: {pct}%; }}
  .barlabel {{ font-size: 12px; color: #555; margin-bottom: 20px; }}
  form.add {{ display: flex; gap: 8px; margin-bottom: 22px; flex-wrap: wrap; }}
  form.add input[type=text] {{
    flex: 1 1 260px; padding: 11px 16px; font-size: 14px;
    border: 1px solid #111; border-radius: 999px; outline: none;
    font-family: inherit; background: #fff;
  }}
  form.add select {{
    padding: 11px 14px; border: 1px solid #111; border-radius: 999px;
    font-family: inherit; font-size: 14px; background: #fff;
  }}
  button {{
    border: 1px solid #111; border-radius: 999px; cursor: pointer;
    font-family: inherit; font-weight: 700; font-size: 13px;
    padding: 11px 20px; background: #111; color: #fff;
  }}
  button:hover {{ opacity: .88; }}
  .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(230px,1fr)); gap: 14px; }}
  .col {{ border: 1px solid #111; border-radius: 18px; overflow: hidden; background: #fff; }}
  .col header {{
    display: flex; justify-content: space-between; align-items: center;
    padding: 10px 14px; border-bottom: 1px solid #111;
    font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: .06em;
  }}
  .count {{ background: #fff; border: 1px solid #111; border-radius: 999px; padding: 1px 9px; font-size: 11px; }}
  .body {{ padding: 10px; display: flex; flex-direction: column; gap: 8px; }}
  .task {{
    display: flex; align-items: center; gap: 6px;
    border: 1px solid #111; border-radius: 12px; padding: 9px 10px;
    font-size: 13.5px; background: #fff;
  }}
  .task > span {{ flex: 1; min-width: 0; }}
  .inline {{ display: inline; margin: 0; }}
  .mini {{ padding: 2px 9px; font-size: 12px; background: #fff; color: #111; }}
  .mini.danger {{ color: #b00; }}
  .empty {{ text-align: center; color: #aaa; font-size: 13px; padding: 14px 0; }}
  footer {{ margin-top: 24px; font-size: 12px; color: #888; }}
</style>
</head>
<body>
<div class="wrap">
  <h1>Task Board</h1>
  <p class="sub">Server-side state, plain form POSTs. Running on Silo &middot; rendered {datetime.now().strftime('%H:%M:%S')}</p>

  <div class="bar"><i></i></div>
  <div class="barlabel">{done} of {len(TASKS)} done &middot; {pct}%</div>

  <form method="post" class="add">
    <input type="hidden" name="action" value="add">
    <input type="text" name="text" placeholder="Add a task&hellip;" required>
    <select name="lane">
      <option>Todo</option><option>Doing</option><option>Done</option>
    </select>
    <button>Add task</button>
  </form>

  <div class="grid">{columns}</div>

  <footer>
    Each button posts back to this same URL, so this page is also a test that
    Silo&rsquo;s proxy forwards POST requests correctly.
  </footer>
</div>
</body>
</html>"""


@app.route("/", methods=["GET", "POST"])
def index():
    global NEXT_ID
    if request.method == "POST":
        action = request.form.get("action")

        if action == "add":
            text = (request.form.get("text") or "").strip()
            lane = request.form.get("lane") or "Todo"
            if text:
                TASKS.append({
                    "id": NEXT_ID,
                    "text": text[:120],
                    "done": lane == "Done",
                    "lane": lane,
                })
                NEXT_ID += 1

        elif action == "advance":
            tid = int(request.form.get("id", 0))
            for t in TASKS:
                if t["id"] == tid:
                    i = LANES.index(t["lane"])
                    t["lane"] = LANES[min(i + 1, len(LANES) - 1)]
                    t["done"] = t["lane"] == "Done"

        elif action == "delete":
            tid = int(request.form.get("id", 0))
            TASKS[:] = [t for t in TASKS if t["id"] != tid]

    return render()


@app.route("/health")
def health():
    return {"ok": True, "app": "task-board", "tasks": len(TASKS)}


if __name__ == "__main__":
    # NOTE: keep the port as a plain literal on the app.run() line.
    # Silo's detector scans for `port=<digits>`; hiding it inside
    # os.environ.get("PORT", 8000) makes detection miss it and fall
    # back to 5000, which would not match what the app actually binds.
    app.run(host="0.0.0.0", port=8000)
